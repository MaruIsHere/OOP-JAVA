
package latihan02;

/**
 *
 * @author Marcellino 18/03/2004
 * 
 */
public class Biodata {
    public void detail(){
        System.out.println("Nama : Marcellino Immanuel Ndoki");
        System.out.println("NIM : 2201010148");
        System.out.println("Alamat : Jalan Raya Dalung Gang Dam Indah");
        System.out.println("Nomor Telepon : 089701836631");
        
    }
}
