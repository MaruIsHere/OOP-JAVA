
package latihan02;

/**
 *
 * @author Marcel 18/03/2024
 */
public class Latihan02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Latiham Membuat Porject Baru");
        System.out.println("Biodata");
        
        Biodata X = new Biodata();
         X.detail();
  
    }
    
}
