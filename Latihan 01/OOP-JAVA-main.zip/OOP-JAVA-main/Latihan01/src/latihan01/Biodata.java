/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihan01;

/**
 *
 * @author LAB F
 */
public class Biodata {
    public void detail(){
        System.out.println("Nama : Marcellino Immanuel Ndoki");
        System.out.println("NIM : 2201010148");
        System.out.println("Alamat : Jalan Raya Dalung Gang Dam Indah");
        System.out.println("Nomor Telepon : 08970137365");           
    }
}
