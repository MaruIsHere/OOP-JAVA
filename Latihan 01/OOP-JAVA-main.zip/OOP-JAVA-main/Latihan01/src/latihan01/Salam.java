
package latihan01;

/**
 *
 * @author Marcel 18/03/2024
 */
public class Salam {
    public void cetak(){
        System.out.println("Data Mahasiswa");
        System.out.println("NIM : 2201010148");
        System.out.println("Nama : Marcellino Immanuel Ndoki");
    }   
    public void Tampil() {
        System.out.println("Cetak teks dengan Method Tampil");
    }
}