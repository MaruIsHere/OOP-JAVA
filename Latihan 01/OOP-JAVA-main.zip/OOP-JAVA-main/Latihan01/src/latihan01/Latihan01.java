package latihan01;

/**
 *
 * @author Marcel 18/03/2024
 */
public class Latihan01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       System.out.println("Saya Belajar Bahasa Pemograman Java");
       System.out.println("Mencoba Menggunakan Bahasa Pemograman Java");
       System.out.println("Saya Berusaha Mempelajari Bahasa Pemograman Java");
       System.out.println("Belajar Menggunakan Print Pada Java");
        
       Salam S = new Salam();
       S.cetak();
       S.Tampil();
       
       System.out.println("  ");
       
       Biodata X = new Biodata();
       X.detail();
      
       
    }
    
}
